#!/bin/sh
./SRBMiner-MULTI --list-devices
